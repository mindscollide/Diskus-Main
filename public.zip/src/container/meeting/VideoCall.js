import React from 'react'
import { AttachmentFiles } from '../../components/elements'
import styles from './Video.module.css'


const VideoCall = () => {
  return (
    <div><AttachmentFiles /></div>
  )
}

export default VideoCall