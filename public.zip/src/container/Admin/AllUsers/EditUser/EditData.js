export const dataSet = [
  {
    name: "JawadFaisal",
    Designation: "Owais Graham",
    Email: "OwaisGraham@gmail.com",
    OrganizationRole: "JawadFaisal",
    UserRole: "AAC",
    UserStatus: "true",
  },
  {
    name: "AunNaqvi",
    Designation: "Talha jasson",
    Email: "Talhajasson@gmail.com",
    OrganizationRole: "Aunnaqvi",
    UserRole: "BCA",
    UserStatus: "true",
  },
  {
    name: "BilalZaidi",
    Designation: "Bilal George",
    Email: "BilalGeorge@gmail.com",
    OrganizationRole: "BilalZaidi",
    UserRole: "DCA",
    UserStatus: "true",
  },
  {
    name: "AunNaqvi",
    Designation: "Leanne Graham",
    Email: "LeanneGraham@gmail.com",
    OrganizationRole: "Aunnaqvi",
    UserRole: "PCA",
    UserStatus: "true",
  },
  {
    name: "JawadFaisal",
    Designation: "Aun Naqvi",
    Email: "AunRaza23@gmail.com",
    OrganizationRole: "JawadFaisal",
    UserRole: "MCA",
    UserStatus: "true",
  },
];


