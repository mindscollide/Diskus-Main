//System Admin Links
const DiskusLinks = [
  {
    menuName: "Home",
    key: 1,
  },
  {
    menuName: "Meeting",
    icon: "icon-meeting mr-1 icon-size-one",
    key: 2,
  },
  {
    menuName: "Notes",
    icon: "icon-note2 mr-1 icon-size-one",
    key: 3,
  },
  {
    menuName: "Notes",
    icon: "icon-note mr-1 icon-size-one",
    key: 4,
  },
  {
    menuName: "Notes",
    icon: "icon-note mr-1 icon-size-one",
    key: 5,
  },
  {
    menuName: "Settings",
    icon: "icon-setting mr-1 icon-size-one",
    key: 6,
  },
];
export { DiskusLinks };
