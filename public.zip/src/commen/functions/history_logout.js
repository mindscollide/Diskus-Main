class Helper {
  static navigate = null;
  static socket = null;
  static isReload = false;
}
export default Helper;
